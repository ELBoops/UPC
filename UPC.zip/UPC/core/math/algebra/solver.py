from __future__ import annotations

from sympy.core.expr import Expr

import core.math.algebra.calculations as calcs
import core.math.algebra.enum as enum

#########
# АЛГЕБРА
#########


def expand_formula(formula_id: int) -> Expr:
	return calcs.calc_expand_formula(formula_id)


def identify_formula(expression: str) -> tuple[int | None, Expr]:
	return calcs.calc_identify_formula(expression)


def formula_selection(input_text, enum_formula):
	option = int(input(input_text))

	match enum_formula:
		case enum.SQUARE_SUM | enum.SQUARE_DIFF | enum.DIFF_OF_SQUARES | enum.CUBE_SUM | enum.CUBE_DIFF | enum.SUM_OF_CUBES | enum.DIFF_OF_CUBES:
			match option:
				case 1:
					steps, result = calcs.calc_solution_steps(enum_formula)
					print("Пошаговое решение:")
					for step in steps:
						print(step)
					print(f"Ответ = {result}")
				case 2:
					a_value = float(input("Введите a: "))
					b_value = float(input("Введите b: "))
					steps, result = calcs.calc_solution_steps(enum_formula, a_value, b_value)
					print("Пошаговое решение:")
					for step in steps:
						print(step)
					print(f"Ответ = {result}")
				case _:
					print("Неверный вариант.")
		case enum.SQUARE_EQUATION:
			a = float(input("Введите a: "))
			b = float(input("Введите b: "))
			c = float(input("Введите c: "))
			print(f"", calcs.calc_square_equation(a, b, c))
		case enum.PARABOLA:
			match option:
				case 1:
					a = float(input("Введите a: "))
					b = float(input("Введите b: "))
					c = float(input("Введите c: "))
					print(f"График параболы: {calcs.calc_parabola_plot(a, b, c)}")
				case 2:
					a = float(input("Введите a: "))
					b = float(input("Введите b: "))
					c = float(input("Введите c: "))
					print(f"Вершины параболы: {calcs.calc_parabola_vertex(a, b, c)}")
				case _:
					print("Неверный вариант.")
		case enum.LOGARITHM:
			match option:
				case 1:
					base = float(input("Введите основание логарифма: "))
					value = float(input("Введите значение логарифма: "))
					print(f"Результат: {calcs.calc_logarithm(base, value)}")
				case 2:
					base = float(input("Введите основание логарифма a: "))
					x_value = float(input("Введите x: "))
					y_value = float(input("Введите y: "))
					steps = calcs.calc_logarithm_properties_multiplication(base, x_value, y_value)
					for step in steps:
						print(step)
				case 3:
					base = float(input("Введите основание логарифма a: "))
					x_value = float(input("Введите x (числитель): "))
					y_value = float(input("Введите y (знаменатель): "))
					steps = calcs.calc_logarithm_properties_division(base, x_value, y_value)
					for step in steps:
						print(step)
				case _:
					print("Неверный вариант.")
		case enum.ARITHMETIC_PROGRESSION:
			match option:
				case 1:
					a1 = float(input("Введите первый член прогрессии a1: "))
					d = float(input("Введите разность прогрессии d: "))
					n = int(input("Введите номер члена прогрессии n: "))
					print(f"n-й член прогрессии: {calcs.calc_arithmetic_progression_nth_term(a1, d, n)}")
				case 2:
					a1 = float(input("Введите первый член прогрессии a1: "))
					d = float(input("Введите разность прогрессии d: "))
					n = int(input("Введите количество членов прогрессии n: "))
					print(f"Сумма n членов прогрессии: {calcs.calc_arithmetic_progression_sum(a1, d, n)}")
				case 3:
					a1 = float(input("Введите первый член прогрессии a1: "))
					a2 = float(input("Введите второй член прогрессии a2: "))
					print(f"Разность прогрессии: {calcs.calc_arithmetic_progression_difference(a1, a2)}")
				case 4:
					an = float(input("Введите n-й член прогрессии an: "))
					d = float(input("Введите разность прогрессии d: "))
					n = int(input("Введите номер члена прогрессии n: "))
					print(f"Первый член прогрессии: {calcs.calc_arithmetic_progression_first_term(an, d, n)}")
				case _:
					print("Неверный вариант.")
		case enum.GEOMETRIC_PROGRESSION:
			match option:
				case 1:
					a1 = float(input("Введите первый член прогрессии a1: "))
					r = float(input("Введите знаменатель прогрессии r: "))
					n = int(input("Введите номер члена прогрессии n: "))
					print(f"n-й член прогрессии: {calcs.calc_geometric_progression_nth_term(a1, r, n)}")
				case 2:
					a1 = float(input("Введите первый член прогрессии a1: "))
					r = float(input("Введите знаменатель прогрессии r: "))
					n = int(input("Введите количество членов прогрессии n: "))
					print(f"Сумма n членов прогрессии: {calcs.calc_geometric_progression_sum(a1, r, n)}")
				case 3:
					a1 = float(input("Введите первый член прогрессии a1: "))
					an = float(input("Введите n-й член прогрессии an: "))
					n = int(input("Введите номер члена прогрессии n: "))
					print(f"Знаменатель прогрессии: {calcs.calc_geometric_progression_common_ratio(a1, an, n)}")
				case 4:
					an = float(input("Введите n-й член прогрессии an: "))
					r = float(input("Введите знаменатель прогрессии r: "))
					n = int(input("Введите номер члена прогрессии n: "))
					print(f"Первый член прогрессии: {calcs.calc_geometric_progression_first_term(an, r, n)}")
				case 5:
					a1 = float(input("Введите первый член прогрессии a1: "))
					r = float(input("Введите знаменатель прогрессии r (должен быть меньше 1): "))
					if r >= 1:
						print("Знаменатель прогрессии должен быть меньше 1 для бесконечно-убывающей прогрессии.")
					else:
						print(f"Сумма бесконечно-убывающей прогрессии: {calcs.calc_geometric_progression_infinite_sum(a1, r)}")
		case enum.TRIGONOMETRY:
			match option:
				case 1:
					print("Определение синуса: sin(θ) = противоположный катет / гипотенуза")
					a = float(input("Введите длину противоположного катета: "))
					c = float(input("Введите длину гипотенузы: "))
					print(f"sin(α) = {calcs.calc_trigonometry_sin(a, c)}")
				case 2:
					print("Определение косинуса: cos(θ) = прилежащий катет / гипотенуза")
					b = float(input("Введите длину прилежащего катета: "))
					c = float(input("Введите длину гипотенузы: "))
					print(f"cos(α) = {calcs.calc_trigonometry_cos(b, c)}")
				case 3:
					print("Определение тангенса: tan(θ) = противоположный катет / прилежащий катет")
					a = float(input("Введите длину противоположного катета: "))
					b = float(input("Введите длину прилежащего катета: "))
					print(f"tan(α) = {calcs.calc_trigonometry_tan(a, b)}")
				case 4:
					print("Определение котангенса: cot(θ) = прилежащий катет / противоположный катет")
					a = float(input("Введите длину противоположного катета: "))
					b = float(input("Введите длину прилежащего катета: "))
					print(f"cot(α) = {calcs.calc_trigonometry_cot(a, b)}")
				case _:
					print("Неверный вариант.")
		case enum.TRIGONOMETRICAL_IDENTITIES:
				match option:
					case 1:
						cos_value = float(input("Введите cos(x): "))
						sign = int(input("Введите знак sin(x) (1 или -1): "))
						steps = calcs.calc_identity_sin_by_cos(cos_value, sign)
						for step in steps:
							print(step)
					case 2:
						sin_value = float(input("Введите sin(x): "))
						sign = int(input("Введите знак cos(x) (1 или -1): "))
						steps = calcs.calc_identity_cos_by_sin(sin_value, sign)
						for step in steps:
							print(step)
					case 3:
						cos_value = float(input("Введите cos(x): "))
						sign = int(input("Введите знак tan(x) (1 или -1): "))
						steps = calcs.calc_identity_tan_by_cos(cos_value, sign)
						for step in steps:
							print(step)
					case 4:
						sin_value = float(input("Введите sin(x): "))
						sign = int(input("Введите знак cot(x) (1 или -1): "))
						steps = calcs.calc_identity_cot_by_sin(sin_value, sign)
						for step in steps:
							print(step)
					case _:
						print("Неверный вариант.")